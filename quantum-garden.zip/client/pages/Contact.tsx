import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

export default function Contact() {
  return (
    <div className="container py-20 max-w-2xl">
      <h1 className="text-3xl font-bold">Contact us</h1>
      <p className="mt-2 text-muted-foreground">We will get back to you within 24 hours.</p>
      <form className="mt-6 grid gap-4" onSubmit={(e) => e.preventDefault()}>
        <Input placeholder="Your email" type="email" required />
        <Input placeholder="Subject" required />
        <Textarea placeholder="Message" className="min-h-[160px]" required />
        <Button type="submit" className="w-full">Send</Button>
      </form>
    </div>
  );
}
