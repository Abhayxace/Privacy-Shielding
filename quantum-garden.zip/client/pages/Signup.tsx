import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";

export default function Signup() {
  return (
    <div className="container py-20 max-w-md">
      <h1 className="text-3xl font-bold">Create your account</h1>
      <form className="mt-6 space-y-4" onSubmit={(e) => e.preventDefault()}>
        <Input placeholder="Full name" required />
        <Input placeholder="Email" type="email" required />
        <Input placeholder="Password" type="password" required />
        <Button type="submit" className="w-full">Sign up</Button>
      </form>
      <p className="mt-4 text-sm text-muted-foreground">Already have an account? <Link to="/login" className="text-brand hover:underline">Log in</Link></p>
    </div>
  );
}
