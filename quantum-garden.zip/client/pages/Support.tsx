import { Link } from "react-router-dom";

export default function Support() {
  return (
    <div className="container py-20">
      <h1 className="text-3xl font-bold">Support</h1>
      <p className="mt-2 text-muted-foreground">Visit our trust center on the homepage or contact us for help.</p>
      <Link to="/#contact" className="btn-primary mt-6 inline-block">Contact support</Link>
    </div>
  );
}
