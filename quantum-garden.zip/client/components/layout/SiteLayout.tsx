import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Shield, Lock, Globe, Menu } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export default function SiteLayout() {
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  const navItems = [
    { to: "/", label: "Home" },
    { to: "/#features", label: "Features" },
    { to: "/#how-it-works", label: "How it works" },
    { to: "/pricing", label: "Pricing" },
    { to: "/blog", label: "Blog" },
    { to: "/#contact", label: "Contact" },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-background/60 backdrop-blur">
        <div className="container flex h-16 items-center justify-between gap-4">
          <Link to="/" className="group inline-flex items-center gap-2" aria-label="Privacy Shield home">
            <span className="relative inline-flex h-8 w-8 items-center justify-center rounded-md bg-brand/20 text-brand shadow-glow">
              <Shield className="h-5 w-5" />
            </span>
            <span className="text-lg font-extrabold tracking-tight">Privacy <span className="text-brand">Shield</span></span>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm">
            {navItems.map((n) => (
              <a key={n.label} href={n.to} className="text-muted-foreground hover:text-foreground transition">
                {n.label}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-3">
            <NavLink to="/login" className={({ isActive }) => cn("btn-ghost px-4 py-2", isActive && "brightness-110")}>Log in</NavLink>
            <NavLink to="/signup" className={({ isActive }) => cn("btn-primary px-4 py-2", isActive && "brightness-110")}>Get Started</NavLink>
          </div>

          <button aria-label="Toggle menu" className="md:hidden inline-flex h-10 w-10 items-center justify-center rounded-md border border-input hover:bg-accent/30" onClick={() => setOpen((o) => !o)}>
            <Menu className="h-5 w-5" />
          </button>
        </div>
        {open && (
          <div className="md:hidden border-t border-white/10">
            <div className="container py-3 flex flex-col gap-2">
              {navItems.map((n) => (
                <a key={n.label} href={n.to} className="px-1 py-2 text-muted-foreground hover:text-foreground transition">
                  {n.label}
                </a>
              ))}
              <div className="flex gap-2 pt-2">
                <Link to="/login" className="btn-ghost w-full text-center">Log in</Link>
                <Link to="/signup" className="btn-primary w-full text-center">Get Started</Link>
              </div>
            </div>
          </div>
        )}
      </header>

      <main id="main" className="flex-1"> 
        <Outlet />
      </main>

      <footer className="border-t border-white/10 bg-background/60">
        <div className="container py-10 grid gap-8 md:grid-cols-4">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2">
              <span className="relative inline-flex h-9 w-9 items-center justify-center rounded-md bg-brand/20 text-brand shadow-glow">
                <Shield className="h-5 w-5" />
              </span>
              <span className="text-lg font-bold">Privacy Shield</span>
            </div>
            <p className="text-sm text-muted-foreground">Protect your digital life with enterprise‑grade privacy.</p>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1"><Lock className="h-3.5 w-3.5" /> SOC 2</span>
              <span className="inline-flex items-center gap-1"><Globe className="h-3.5 w-3.5" /> GDPR</span>
            </div>
          </div>
          <div>
            <p className="font-semibold mb-3">Product</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="/#features" className="hover:text-foreground">Features</a></li>
              <li><a href="/#how-it-works" className="hover:text-foreground">How it works</a></li>
              <li><a href="/pricing" className="hover:text-foreground">Pricing</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-3">Company</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="/blog" className="hover:text-foreground">Blog & Updates</a></li>
              <li><a href="/#team" className="hover:text-foreground">Team</a></li>
              <li><a href="/#contact" className="hover:text-foreground">Contact</a></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold mb-3">Legal</p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="/#security" className="hover:text-foreground">Security</a></li>
              <li><a href="/#privacy" className="hover:text-foreground">Privacy Policy</a></li>
              <li><a href="/#compliance" className="hover:text-foreground">Trust & Compliance</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-white/10">
          <div className="container flex flex-col md:flex-row items-center justify-between py-6 text-xs text-muted-foreground">
            <p>© {new Date().getFullYear()} Privacy Shield. All rights reserved.</p>
            <div className="flex gap-4">
              <Link to="/support" className="hover:text-foreground">Support</Link>
              <Link to="/contact" className="hover:text-foreground">Contact</Link>
              <a href="/#privacy" className="hover:text-foreground">Privacy</a>
              <a href="/#security" className="hover:text-foreground">Security</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
