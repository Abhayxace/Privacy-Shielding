export default function Blog() {
  return (
    <div className="container py-20">
      <h1 className="text-3xl font-bold">Blog & Updates</h1>
      <p className="mt-2 text-muted-foreground">Posts coming soon. Meanwhile, check updates on the homepage.</p>
    </div>
  );
}
