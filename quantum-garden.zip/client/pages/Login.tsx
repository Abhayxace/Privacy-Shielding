import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "react-router-dom";

export default function Login() {
  return (
    <div className="container py-20 max-w-md">
      <h1 className="text-3xl font-bold">Log in</h1>
      <form className="mt-6 space-y-4" onSubmit={(e) => e.preventDefault()}>
        <Input placeholder="Email" type="email" required />
        <Input placeholder="Password" type="password" required />
        <Button type="submit" className="w-full">Log in</Button>
      </form>
      <p className="mt-4 text-sm text-muted-foreground">No account? <Link to="/signup" className="text-brand hover:underline">Sign up</Link></p>
    </div>
  );
}
