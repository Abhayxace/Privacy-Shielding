import { motion } from "framer-motion";
import { Shield, Lock, Network, Eye, BarChart3, Users, CreditCard, Globe2, CheckCircle2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { Link } from "react-router-dom";
import { LineChart, Line, ResponsiveContainer, Tooltip } from "recharts";

const chartData = [
  { t: 1, v: 8 },
  { t: 2, v: 12 },
  { t: 3, v: 9 },
  { t: 4, v: 14 },
  { t: 5, v: 10 },
  { t: 6, v: 16 },
];

const section = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

export default function Index() {
  const [vpnOn, setVpnOn] = useState(true);
  const [tracking, setTracking] = useState(true);

  return (
    <div className="relative">
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-grid bg-[size:24px_24px] opacity-20" aria-hidden />
        <div className="container pt-20 pb-16 md:pt-28 md:pb-24">
          <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="mx-auto max-w-4xl text-center">
            <div className="mx-auto mb-6 inline-flex items-center gap-2 rounded-full border border-white/10 bg-black/40 px-3 py-1 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-brand" /> Now in private beta — join the waitlist
            </div>
            <h1 className="text-balance text-4xl font-extrabold tracking-tight md:text-6xl">
              Protect your digital life with <span className="text-brand">Privacy Shield</span>
            </h1>
            <p className="mt-4 text-lg text-muted-foreground md:text-xl">
              A modern privacy suite with permission control, built‑in VPN, dark web monitoring, analytics,
              and family/business modules — all in a cybersecurity‑inspired dark theme.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <Link to="/signup" className="btn-primary">
                Get Started Free
              </Link>
              <Link to="/pricing" className="btn-ghost">View Pricing</Link>
            </div>
            <div className="mt-10 grid grid-cols-3 gap-6 text-sm text-muted-foreground">
              <div className="rounded-md border border-white/10 bg-black/20 p-3">
                ISO 27001
              </div>
              <div className="rounded-md border border-white/10 bg-black/20 p-3">
                SOC 2
              </div>
              <div className="rounded-md border border-white/10 bg-black/20 p-3">
                GDPR Ready
              </div>
            </div>
          </motion.div>
        </div>
        <div className="pointer-events-none absolute inset-x-0 -bottom-20 h-40 bg-gradient-to-b from-transparent to-background" aria-hidden />
      </section>

      {/* FEATURE STRIP / INTERACTIVE DEMOS */}
      <motion.section id="features" variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container pb-16">
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {/* Permission Management */}
          <div className="group relative overflow-hidden rounded-xl border border-white/10 bg-card p-5 shadow-glow">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-brand">
                <Lock className="h-5 w-5" />
                <p className="font-semibold">Permissions</p>
              </div>
              <span className="text-xs text-muted-foreground">Live</span>
            </div>
            <div className="mt-4 space-y-3 text-sm">
              {[
                { k: "Camera", v: false },
                { k: "Microphone", v: true },
                { k: "Location", v: false },
                { k: "Contacts", v: true },
              ].map((row) => (
                <button key={row.k} className="flex w-full items-center justify-between rounded-md border border-white/10 bg-black/20 px-3 py-2 text-left hover:bg-black/30">
                  <span>{row.k}</span>
                  <span className={row.v ? "text-brand" : "text-muted-foreground"}>{row.v ? "Allowed" : "Blocked"}</span>
                </button>
              ))}
            </div>
          </div>

          {/* VPN */}
          <div className="relative overflow-hidden rounded-xl border border-white/10 bg-card p-5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-brand">
                <Network className="h-5 w-5" />
                <p className="font-semibold">VPN</p>
              </div>
            </div>
            <div className="mt-6 flex items-center justify-between rounded-lg border border-white/10 bg-black/20 p-4">
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <p className="text-lg font-semibold">{vpnOn ? "Secure" : "Off"}</p>
              </div>
              <button onClick={() => setVpnOn((v) => !v)} className="btn-primary px-4 py-2">
                {vpnOn ? "Disconnect" : "Connect"}
              </button>
            </div>
            <div className="mt-4 text-xs text-muted-foreground">Location: {vpnOn ? "Zurich" : "—"} • Protocol: WireGuard</div>
          </div>

          {/* Dark Web Monitor */}
          <div className="relative overflow-hidden rounded-xl border border-white/10 bg-card p-5">
            <div className="flex items-center gap-2 text-brand">
              <Eye className="h-5 w-5" />
              <p className="font-semibold">Dark Web Monitor</p>
            </div>
            <ul className="mt-4 space-y-3 text-sm">
              {["Credential leak — email@domain.com", "Data dump mention — Aditya Kumar", "Breach alert — Payment token"].map((t, i) => (
                <li key={i} className="flex items-start gap-2 rounded-md border border-white/10 bg-black/20 p-3">
                  <CheckCircle2 className="h-4 w-4 text-brand" />
                  <span className="text-foreground/90">{t}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Analytics */}
          <div className="relative overflow-hidden rounded-xl border border-white/10 bg-card p-5">
            <div className="flex items-center gap-2 text-brand">
              <BarChart3 className="h-5 w-5" />
              <p className="font-semibold">Privacy Analytics</p>
            </div>
            <div className="mt-4 h-28 rounded-md border border-white/10 bg-black/20 p-2">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
                  <Tooltip contentStyle={{ background: "hsl(222 33% 7%)", border: "1px solid hsl(217.2 16.6% 16.5%)", borderRadius: 8 }} cursor={{ stroke: "hsl(150 85% 46% / 0.2)" }} />
                  <Line type="monotone" dataKey="v" stroke="hsl(150 85% 46%)" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">Track exposure score and harden your privacy over time.</p>
          </div>
        </div>
      </motion.section>

      {/* DETAILED FEATURES */}
      <motion.section variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <div className="mx-auto max-w-3xl text-center">
          <h2 className="text-3xl font-bold tracking-tight">Everything you need to stay private</h2>
          <p className="mt-3 text-muted-foreground">Permission management, VPN integration, dark web monitoring, analytics, and family/payment modules—beautifully integrated.</p>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {[
            { icon: <Lock className="h-5 w-5" />, title: "App Permission Control", desc: "See and revoke invasive permissions across devices.", badge: "Realtime" },
            { icon: <Network className="h-5 w-5" />, title: "Next‑gen VPN", desc: "Auto‑connect, kill‑switch, WireGuard protocol.", badge: "Secure" },
            { icon: <Eye className="h-5 w-5" />, title: "Dark Web Scan", desc: "Continuous credential leak detection.", badge: "24/7" },
            { icon: <BarChart3 className="h-5 w-5" />, title: "Analytics", desc: "Privacy exposure score and insights.", badge: "Insights" },
            { icon: <Users className="h-5 w-5" />, title: "Family Module", desc: "Profiles, screen time, safe permissions.", badge: "Family" },
            { icon: <CreditCard className="h-5 w-5" />, title: "Payment Privacy", desc: "Masked cards and merchant controls.", badge: "Payments" },
          ].map((f) => (
            <div key={f.title} className="group rounded-xl border border-white/10 bg-card p-5 transition hover:shadow-glow">
              <div className="flex items-center gap-2 text-brand">
                {f.icon}
                <span className="text-xs">{f.badge}</span>
              </div>
              <p className="mt-3 text-lg font-semibold">{f.title}</p>
              <p className="mt-1 text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </motion.section>

      {/* HOW IT WORKS / TECH */}
      <motion.section id="how-it-works" variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <div className="grid items-start gap-10 md:grid-cols-2">
          <div>
            <h3 className="text-2xl font-bold">How it works</h3>
            <ol className="mt-4 space-y-4 text-sm">
              <li className="rounded-lg border border-white/10 bg-black/20 p-4"><span className="font-semibold text-brand">1.</span> Connect your devices and choose default privacy level.</li>
              <li className="rounded-lg border border-white/10 bg-black/20 p-4"><span className="font-semibold text-brand">2.</span> Privacy Shield enforces safe permissions and VPN policies.</li>
              <li className="rounded-lg border border-white/10 bg-black/20 p-4"><span className="font-semibold text-brand">3.</span> Continuous monitoring detects risks and recommends fixes.</li>
            </ol>
          </div>
          <div>
            <h3 className="text-2xl font-bold">Tech behind it</h3>
            <ul className="mt-4 space-y-4 text-sm">
              <li className="rounded-lg border border-white/10 bg-black/20 p-4">Client‑side permission auditor, on‑device ML anomaly detection.</li>
              <li className="rounded-lg border border-white/10 bg-black/20 p-4">Zero‑knowledge architecture for encrypted sync and logs.</li>
              <li className="rounded-lg border border-white/10 bg-black/20 p-4">Hardened VPN core (WireGuard) with DNS‑over‑HTTPS.</li>
            </ul>
          </div>
        </div>
      </motion.section>

      {/* TRUST & COMPLIANCE / SECURITY & PRIVACY */}
      <motion.section id="security" variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <div className="grid gap-6 md:grid-cols-3">
          <div className="rounded-xl border border-white/10 bg-card p-6">
            <h4 className="text-lg font-semibold">Security</h4>
            <p className="mt-2 text-sm text-muted-foreground">End‑to‑end encryption, 2FA, device keys, and SOC 2 controls.</p>
          </div>
          <div id="privacy" className="rounded-xl border border-white/10 bg-card p-6">
            <h4 className="text-lg font-semibold">Privacy Policy</h4>
            <p className="mt-2 text-sm text-muted-foreground">We never sell data. Telemetry is optional and anonymized.</p>
          </div>
          <div id="compliance" className="rounded-xl border border-white/10 bg-card p-6">
            <h4 className="text-lg font-semibold">Trust & Compliance</h4>
            <p className="mt-2 text-sm text-muted-foreground">GDPR, ISO 27001, SOC 2 Type II. Data residency options.</p>
          </div>
        </div>
      </motion.section>

      {/* USE CASES */}
      <motion.section variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <h3 className="text-2xl font-bold">Use cases & benefits</h3>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[
            { t: "Individuals", d: "Protect identity, stop tracking, safer browsing." },
            { t: "Families", d: "Manage profiles, safe permissions, payment controls." },
            { t: "Business", d: "Compliance‑ready privacy for teams and devices." },
          ].map((u) => (
            <div key={u.t} className="rounded-xl border border-white/10 bg-card p-6">
              <h4 className="font-semibold">{u.t}</h4>
              <p className="mt-2 text-sm text-muted-foreground">{u.d}</p>
            </div>
          ))}
        </div>
      </motion.section>

      {/* TEAM / MISSION */}
      <motion.section id="team" variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <div className="grid items-start gap-8 md:grid-cols-2">
          <div>
            <h3 className="text-2xl font-bold">Our mission</h3>
            <p className="mt-2 text-sm text-muted-foreground">Make privacy effortless and accessible to everyone without compromising security or speed.</p>
          </div>
          <div>
            <h3 className="text-2xl font-bold">Our team</h3>
            <p className="mt-2 text-sm text-muted-foreground">Security engineers and designers with experience from top privacy products.</p>
          </div>
        </div>
      </motion.section>

      {/* BLOG PREVIEW */}
      <motion.section variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <div className="flex items-center justify-between">
          <h3 className="text-2xl font-bold">Blog & updates</h3>
          <Link to="/blog" className="text-sm text-brand hover:underline">View all</Link>
        </div>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          {[1,2,3].map((i) => (
            <Link key={i} to="/blog" className="rounded-xl border border-white/10 bg-card p-6 hover:shadow-glow">
              <p className="text-sm text-muted-foreground">Update</p>
              <p className="mt-2 font-semibold">Privacy Shield {i}.0 — Release notes</p>
            </Link>
          ))}
        </div>
      </motion.section>

      {/* PRICING */}
      <motion.section id="pricing" variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-16">
        <div className="mx-auto max-w-2xl text-center">
          <h3 className="text-3xl font-bold">Simple, transparent pricing</h3>
          <p className="mt-2 text-muted-foreground">Start free. Upgrade anytime.</p>
        </div>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {[
            { name: "Free", price: "$0", features: ["VPN (limited)", "Permission viewer", "Basic monitoring"] },
            { name: "Premium", price: "$7/mo", features: ["Unlimited VPN", "Dark web monitoring", "Analytics & insights"] },
            { name: "Family/Business", price: "$14+/mo", features: ["Profiles & policies", "Admin controls", "Priority support"] },
          ].map((p) => (
            <div key={p.name} className="rounded-2xl border border-white/10 bg-card p-6">
              <h4 className="text-lg font-semibold">{p.name}</h4>
              <p className="mt-1 text-3xl font-extrabold">{p.price}</p>
              <ul className="mt-4 space-y-2 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-brand" /> {f}</li>
                ))}
              </ul>
              <Link to="/signup" className="btn-primary mt-6 block w-full text-center">Choose {p.name}</Link>
            </div>
          ))}
        </div>
      </motion.section>

      {/* CONTACT & SUPPORT */}
      <motion.section id="contact" variants={section} initial="hidden" whileInView="show" viewport={{ once: true, margin: "-100px" }} className="container py-12 md:py-20">
        <div className="grid gap-8 md:grid-cols-2">
          <div>
            <h3 className="text-2xl font-bold">Contact & Support</h3>
            <p className="mt-2 text-sm text-muted-foreground">Have questions? Our team will reply within 24 hours.</p>
            <div className="mt-6 rounded-xl border border-white/10 bg-card p-6">
              <form className="space-y-4" onSubmit={(e) => e.preventDefault()} aria-label="Contact form">
                <Input placeholder="Your email" type="email" required />
                <Input placeholder="Subject" required />
                <Textarea placeholder="Message" className="min-h-[120px]" required />
                <Button type="submit" className="w-full">Send message</Button>
              </form>
            </div>
          </div>
          <div className="rounded-xl border border-white/10 bg-card p-6">
            <h4 className="font-semibold">Trust center</h4>
            <ul className="mt-4 space-y-3 text-sm text-muted-foreground">
              <li>• Status: All systems operational</li>
              <li>• Data residency: EU/US options</li>
              <li>• Compliance: SOC 2 Type II, ISO 27001, GDPR</li>
            </ul>
            <Link to="/support" className="mt-6 inline-block text-brand hover:underline">Visit support →</Link>
          </div>
        </div>
      </motion.section>
    </div>
  );
}
