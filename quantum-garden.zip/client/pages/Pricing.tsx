import { Link } from "react-router-dom";

export default function Pricing() {
  return (
    <div className="container py-20">
      <h1 className="text-3xl font-bold">Pricing</h1>
      <p className="mt-2 text-muted-foreground">See the pricing section on the homepage for a quick overview.</p>
      <Link to="/#pricing" className="btn-primary mt-6 inline-block">View pricing on homepage</Link>
    </div>
  );
}
